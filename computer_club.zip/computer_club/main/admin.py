from django.contrib import admin
from .models import StudentInfo, EducationalProgram, ProgramManagement, Classmate

class EducationalProgramInline(admin.StackedInline):
    model = EducationalProgram
    extra = 1

class ProgramManagementInline(admin.TabularInline):
    model = ProgramManagement
    extra = 2
    fields = ('role', 'full_name', 'email', 'photo')

class ClassmateInline(admin.TabularInline):
    model = Classmate
    extra = 2
    fields = ('full_name', 'email', 'phone', 'photo')

@admin.register(StudentInfo)
class StudentInfoAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'email', 'program', 'created_at')
    list_filter = ('program', 'created_at')
    search_fields = ('full_name', 'email', 'program')
    inlines = [EducationalProgramInline, ProgramManagementInline, ClassmateInline]
    fieldsets = (
        ('Основная информация', {
            'fields': ('full_name', 'photo', 'email', 'program')
        }),
    )

@admin.register(EducationalProgram)
class EducationalProgramAdmin(admin.ModelAdmin):
    list_display = ('name', 'student')
    search_fields = ('name', 'student__full_name')
    fieldsets = (
        ('Основная информация', {
            'fields': ('student', 'name', 'url')
        }),
        ('Описание программы', {
            'fields': ('description', 'skills', 'advantages', 'prospects')
        }),
    )

@admin.register(ProgramManagement)
class ProgramManagementAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'role', 'email', 'student')
    list_filter = ('role',)
    search_fields = ('full_name', 'email', 'student__full_name')
    fieldsets = (
        ('Основная информация', {
            'fields': ('student', 'role', 'full_name', 'email', 'photo')
        }),
    )

@admin.register(Classmate)
class ClassmateAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'email', 'phone', 'student')
    search_fields = ('full_name', 'email', 'phone', 'student__full_name')
    fieldsets = (
        ('Основная информация', {
            'fields': ('student', 'full_name', 'email', 'phone', 'photo')
        }),
    )

