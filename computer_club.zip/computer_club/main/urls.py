from django.urls import path
from . import views

urlpatterns = [
    # Старые маршруты
    path('', views.index, name='index'),
    path('about/', views.about, name='about'),
    path('location/', views.location, name='location'),
    path('exer1/', views.exer1, name='exer1'),
    path('exer2/', views.exer2, name='exer2'),
    path('game/', views.game, name='game'),
    
    # Маршруты для формы информации о студенте
    path('student-info/form/', views.student_info_form, name='student_info_form'),
    path('student-info/list/', views.student_info_list, name='student_info_list'),
]