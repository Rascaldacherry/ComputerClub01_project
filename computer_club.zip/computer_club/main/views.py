from django.shortcuts import render, redirect
from django.contrib import messages
from .models import StudentInfo, EducationalProgram
from .forms import StudentInfoForm
from django.db.models import Count
from django.db.models import Q
from datetime import datetime

def index(request):
    return render(request, 'main/index.html')

def about(request):
    return render(request, 'main/about.html')

def location(request):
    return render(request, 'main/location.html')

def game(request):
    return render(request, 'main/game.html')

def exer1(request):
    result = None
    if request.method == "POST":
        a = float(request.POST.get("a"))
        b = float(request.POST.get("b"))
        c = float(request.POST.get("c"))
        d = float(request.POST.get("d"))
        if (a <= c and b <= d) or (b <= c and a <= d):
            result = "Да, прямоугольник может поместиться."
        else:
            result = "Нет, прямоугольник не помещается."
    return render(request, "main/exer1.html", {"result": result})

def exer2(request):
    # Получаем информацию о студенте
    try:
        student = StudentInfo.objects.get(full_name="Васясин Дмитрий Алексеевич")
    except StudentInfo.DoesNotExist:
        return render(request, "main/exer2.html", {
            "error": "Информация о студенте не найдена."
        })
    
    # Получаем информацию о менеджменте
    try:
        manager = StudentInfo.objects.get(full_name="Заяц Елена Игоревна")
        supervisor = StudentInfo.objects.get(full_name="Щербакова Алина Вячеславовна")
    except StudentInfo.DoesNotExist:
        return render(request, "main/exer2.html", {
            "error": "Информация о менеджменте не найдена."
        })

    # Получаем информацию о сокурсниках
    try:
        classmates = StudentInfo.objects.filter(
            full_name__in=[
                "Голенцова Дарья Васильевна",
                "Барзунов Дмитрий Александрович",
                "Ведерников Илья Сергеевич"
            ]
        )
    except StudentInfo.DoesNotExist:
        classmates = []

    try:
        program = EducationalProgram.objects.get(name="Мировая Экономика")
        program_info = {
            "name": program.name,
            "description": program.description,
            "url": program.url,
            "skills": program.skills,
            "advantages": program.advantages,
            "prospects": program.prospects
        }
    except EducationalProgram.DoesNotExist:
        program_info = {
            "name": "Мировая Экономика",
            "description": "Цель программы - подготовка специалистов, способных свободно ориентироваться в многообразии теоретических и прикладных проблем, которые ставятся перед экономистом динамичными изменениями, происходящими в современном мире. Выпускники умеют анализировать товарные и валютные рынки, разбираются в формах внешнеэкономической деятельности и закономерностях интеграционных процессов в современном мире, знакомы с условиями повышения конкурентоспособности товаров и услуг и принципами работы международных экономических организаций.",
            "url": "",
            "skills": "",
            "advantages": "",
            "prospects": ""
        }
    
    # Формируем данные для шаблона
    data = {
        "student": {
            "full_name": student.full_name,
            "email": student.email,
            "photo": student.photo,
            "program": student.program
        },
        "manager": {
            "full_name": manager.full_name,
            "email": manager.email,
            "photo": manager.photo,
            "role": "Менеджер программы"
        },
        "supervisor": {
            "full_name": supervisor.full_name,
            "email": supervisor.email,
            "photo": supervisor.photo,
            "role": "Академический руководитель"
        },
        "program_info": program_info,
        "classmates": classmates
    }
    
    return render(request, "main/exer2.html", data)

def student_info_form(request):
    if request.method == 'POST':
        form = StudentInfoForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, 'Информация успешно сохранена!')
            return redirect('student_info_list')
    else:
        form = StudentInfoForm()
    return render(request, 'main/student_info_form.html', {'form': form})

def student_info_list(request):
    # Получаем параметры фильтрации
    search_query = request.GET.get('search', '')
    program_filter = request.GET.get('program', '')
    date_filter = request.GET.get('date', '')
    sort_by = request.GET.get('sort', '')  # Новый параметр сортировки
    
    # Базовый queryset
    students = StudentInfo.objects.all()
    
    # Применяем фильтры
    if search_query:
        students = students.filter(
            Q(full_name__icontains=search_query) |
            Q(email__icontains=search_query)
        )
    
    if program_filter:
        students = students.filter(program=program_filter)
        
    if date_filter:
        try:
            filter_date = datetime.strptime(date_filter, '%Y-%m-%d').date()
            students = students.filter(created_at__date=filter_date)
        except ValueError:
            pass
    
    # Применяем сортировку
    if sort_by == 'name_asc':
        students = students.order_by('full_name')
    elif sort_by == 'name_desc':
        students = students.order_by('-full_name')
    elif sort_by == 'date_asc':
        students = students.order_by('created_at')
    elif sort_by == 'date_desc':
        students = students.order_by('-created_at')
    
    # Получаем статистику по программам
    program_stats = StudentInfo.objects.values('program').annotate(
        count=Count('id')
    ).order_by('-count')
    
    # Получаем уникальные программы для фильтра
    programs = StudentInfo.objects.values_list('program', flat=True).distinct()
    
    context = {
        'students': students,
        'program_stats': program_stats,
        'programs': programs,
        'search_query': search_query,
        'program_filter': program_filter,
        'date_filter': date_filter,
        'sort_by': sort_by,  # Добавляем текущую сортировку в контекст
    }
    
    return render(request, 'main/student_info_list.html', context)
