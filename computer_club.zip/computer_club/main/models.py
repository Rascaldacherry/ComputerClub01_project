from django.db import models

class StudentInfo(models.Model):
    full_name = models.CharField(max_length=255, verbose_name="ФИО")
    photo = models.ImageField(upload_to='students/', verbose_name="Фото")
    email = models.EmailField(verbose_name="Email")
    program = models.CharField(max_length=255, verbose_name="Образовательная программа")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Дата создания")

    def __str__(self):
        return self.full_name

    class Meta:
        verbose_name = "Информация о студенте"
        verbose_name_plural = "Информация о студентах"
        ordering = ['-created_at']

class EducationalProgram(models.Model):
    name = models.CharField(max_length=255, verbose_name='Название программы')
    url = models.URLField(verbose_name='Ссылка на страницу программы')
    description = models.TextField(verbose_name='Описание программы')
    skills = models.TextField(verbose_name='Чему научитесь')
    advantages = models.TextField(verbose_name='Преимущества программы')
    prospects = models.TextField(verbose_name='Перспективы после обучения')
    student = models.OneToOneField(StudentInfo, on_delete=models.CASCADE, related_name='program_info')

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Образовательная программа'
        verbose_name_plural = 'Образовательные программы'

class ProgramManagement(models.Model):
    ROLE_CHOICES = [
        ('academic', 'Академический руководитель'),
        ('manager', 'Менеджер программы'),
    ]
    

    student = models.ForeignKey(StudentInfo, on_delete=models.CASCADE, related_name='management')
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, verbose_name='Роль')
    full_name = models.CharField(max_length=255, verbose_name='ФИО')
    photo = models.ImageField(upload_to='management/', verbose_name='Фото')
    email = models.EmailField(max_length=254, verbose_name='Email')

    class Meta:
        verbose_name = 'Менеджмент программы'
        verbose_name_plural = 'Менеджмент программ'

class Classmate(models.Model):
    student = models.ForeignKey(StudentInfo, on_delete=models.CASCADE, related_name='classmates')
    full_name = models.CharField(max_length=255, verbose_name='ФИО')
    photo = models.ImageField(upload_to='classmates/', verbose_name='Фото')
    email = models.EmailField(max_length=254, verbose_name='Email')
    phone = models.CharField(max_length=20, verbose_name='Телефон')

    class Meta:
        verbose_name = 'Сокурсник'
        verbose_name_plural = 'Сокурсники'